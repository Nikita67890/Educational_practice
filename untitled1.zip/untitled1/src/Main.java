//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //int number = 1000;
        //for (int i = -137 + 1; i < number; i++)
        //{
            //System.out.println(number);
            //number -= 7;
        //}
        // Метод перебора
        for (int i = 1000; i > 0; i -= 7)
        {
            System.out.println(i);
        }
    }
}

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static List<User> users = new ArrayList<>();
    private static Hotel hotel;

    public static void main(String[] args) {
        List<Room> rooms = initializeRooms();
        List<Time> availableTimes = initializeAvailableTimes();
        hotel = new Hotel(rooms, availableTimes);

        while (true) {
            System.out.println("Выберите действие:");
            System.out.println("1. Регистрация");
            System.out.println("2. Бронирование номера");
            System.out.println("3. Выход");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    registerUser();
                    break;
                case 2:
                    bookRoom();
                    break;
                case 3:
                    System.out.println("До свидания!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Неверный выбор.");
            }
        }
    }

    private static List<Room> initializeRooms() {
        List<Room> rooms = new ArrayList<>();
        // Создание номеров на разных этажах
        rooms.add(new Room(101, 1));
        rooms.add(new Room(102, 1));
        rooms.add(new Room(103, 1));
        rooms.add(new Room(201, 2));
        rooms.add(new Room(202, 2));
        rooms.add(new Room(203, 2));
        return rooms;
    }

    private static List<Time> initializeAvailableTimes() {
        List<Time> availableTimes = new ArrayList<>();
        availableTimes.add(new Time("10:00"));
        availableTimes.add(new Time("13:00"));
        return availableTimes;
    }

    private static void registerUser() {
        System.out.println("Введите ваше имя и  фамилию:");
        String name = scanner.nextLine();
        User user = new User(name);
        users.add(user);
        System.out.println("Регистрация успешна.");
    }

    private static void bookRoom() {
        System.out.println("Доступные номера:");
        List<Room> availableRooms = hotel.getAvailableRooms();
        for (Room room : availableRooms) {
            System.out.println("Номер: " + room.getRoomNumber() + ", Этаж: " + room.getFloor());
        }

        System.out.println("Введите номер комнаты для бронирования:");
        int roomNumber = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Доступное время:");
        List<Time> availableTimes = hotel.getAvailableTimes();
        for (Time time : availableTimes) {
            System.out.println(time.getTimeSlot());
        }

        System.out.println("Введите время бронирования (в формате 10:00 или 13:00):");
        String timeSlot = scanner.nextLine();

        Room room = hotel.getRoomByNumber(roomNumber);
        Time chosenTime = null;
        for (Time time : availableTimes) {
            if (time.getTimeSlot().equals(timeSlot)) {
                chosenTime = time;
                break;
            }
        }

        if (room != null && !room.isBooked() && chosenTime != null) {
            room.bookRoom(new Date());
            System.out.println("Номер успешно забронирован.");
        } else {
            System.out.println("Номер комнаты уже занят или время недоступно.");
        }
    }
}
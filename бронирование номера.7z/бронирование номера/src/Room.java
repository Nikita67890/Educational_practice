import java.util.Date;

class Room {
    private int roomNumber;
    private int floor;
    private boolean isBooked;
    private Date bookingTime;

    public Room(int roomNumber, int floor) {
        this.roomNumber = roomNumber;
        this.floor = floor;
        this.isBooked = false;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public int getFloor() {
        return floor;
    }

    public boolean isBooked() {
        return isBooked;
    }

    public void bookRoom(Date bookingTime) {
        isBooked = true;
        this.bookingTime = bookingTime;
    }

    public Date getBookingTime() {
        return bookingTime;
    }
}
import java.util.ArrayList;
import java.util.List;

class Hotel {
    private List<Room> rooms;
    private List<Time> availableTimes;

    public Hotel(List<Room> rooms, List<Time> availableTimes) {
        this.rooms = rooms;
        this.availableTimes = availableTimes;
    }

    public List<Room> getAvailableRooms() {
        List<Room> availableRooms = new ArrayList<>();
        for (Room room : rooms) {
            if (!room.isBooked()) {
                availableRooms.add(room);
            }
        }
        return availableRooms;
    }

    public Room getRoomByNumber(int roomNumber) {
        for (Room room : rooms) {
            if (room.getRoomNumber() == roomNumber) {
                return room;
            }
        }
        return null;
    }

    public List<Time> getAvailableTimes() {
        return availableTimes;
    }
}
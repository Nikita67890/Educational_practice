using UnityEngine;

public class Pipe : MonoBehaviour
{
    public float speed;
    public LoseWindow Win;

    private void Update()
    {
        transform.Translate(Vector2.left * speed * Time.deltaTime);
    }

    public void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("count"))
        {
            if (other.TryGetComponent<Player>(out Player player))
            {
                if (ScoreManager.Instance != null)
                {
                    ScoreManager.Instance.SetScore(1);
                }
                else
                {
                    Debug.LogError("ScoreManager.Instance is null");
                }
            }
        }
    }
}
using UnityEngine;
using TMPro;

public class LoseWindow : MonoBehaviour
{
    [SerializeField] public TextMeshProUGUI scoreText;
    public TextMeshProUGUI bestScoreTXT;

    public void PlayerLose()
    {
        if (ScoreManager.Instance == null)
        {
            Debug.LogError("ScoreManager.Instance is null");
            return;
        }

        if (scoreText == null)
        {
            Debug.LogError("scoreText is not assigned");
            return;
        }

        if (bestScoreTXT == null)
        {
            Debug.LogError("bestScoreTXT is not assigned");
            return;
        }

        int score = ScoreManager.Instance.score;
        scoreText.text = score.ToString();
        int bestScore = PlayerPrefs.GetInt("BestScore");
        if (score > bestScore)
        {
            bestScore = score;
        }

        bestScoreTXT.text = bestScore.ToString();
        PlayerPrefs.SetInt("BestScore", bestScore);
    }
}